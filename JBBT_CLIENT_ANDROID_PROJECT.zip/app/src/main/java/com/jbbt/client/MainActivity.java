package com.jbbt.client;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(5, 12, 29);
    private final int panel = Color.rgb(13, 28, 54);
    private final int cyan = Color.rgb(67, 207, 255);
    private LinearLayout content;
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        showHome();
    }

    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(24);
        if (stroke != 0) d.setStroke(2, stroke);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(4, 8, 4, 8);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void base(String subtitle) {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = column();
        page.setPadding(22, 28, 22, 28);
        page.setBackgroundColor(bg);

        TextView brand = text("✦ JBBT CLIENT", 27, cyan, true);
        page.addView(brand);
        page.addView(text("NEON ICE  •  ANDROID EDITION", 11, Color.LTGRAY, true));
        page.addView(text(subtitle, 16, Color.WHITE, true));
        content = column();
        content.setPadding(0, 14, 0, 10);
        page.addView(content);
        status = text("Companion app • Not connected to Minecraft", 11, Color.LTGRAY, false);
        page.addView(status);
        scroll.addView(page);
        setContentView(scroll);
    }

    private void card(String title, String detail, View.OnClickListener click) {
        LinearLayout box = column();
        box.setPadding(16, 12, 16, 12);
        box.setBackground(shape(panel, Color.rgb(35, 105, 160)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = 12;
        content.addView(box, lp);
        box.addView(text(title, 17, cyan, true));
        box.addView(text(detail, 13, Color.WHITE, false));
        if (click != null) box.setOnClickListener(click);
    }

    private void showHome() {
        base("CLIENT DASHBOARD");
        card("HUD CUSTOMIZER", "Preview and configure a clean HUD layout.", v -> showHud());
        card("CROSSHAIR STUDIO", "Choose a crosshair style and color.", v -> showCrosshair());
        card("ZOOM SETTINGS", "Set a preferred zoom level for your setup.", v -> showZoom());
        card("PACK MANAGER", "Open Minecraft's pack settings to manage resource packs.", v -> showPacks());
        card("ABOUT JBBT", "Version 1.0 • Companion app information.", v -> showAbout());
    }

    private void heading(String title, String detail) {
        base(title);
        content.addView(text(detail, 14, Color.WHITE, false));
        Button back = new Button(this);
        back.setText("← BACK TO DASHBOARD");
        back.setTextColor(Color.WHITE);
        back.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(20, 95, 145)));
        back.setOnClickListener(v -> showHome());
        content.addView(back);
    }

    private void showHud() {
        heading("HUD CUSTOMIZER", "These are layout preferences and previews. Android does not read live Minecraft FPS, CPS, ping, keystrokes, or armor data from this companion app.");
        String[] items = {"FPS counter (preview toggle)", "CPS counter (preview toggle)", "Ping display (preview toggle)", "Keystrokes panel (preview toggle)", "Armor panel (preview toggle)"};
        for (String item : items) {
            Switch s = new Switch(this);
            s.setText(item);
            s.setTextColor(Color.WHITE);
            s.setPadding(4, 12, 4, 12);
            content.addView(s);
        }
    }

    private void showCrosshair() {
        heading("CROSSHAIR STUDIO", "Choose a preview style. This changes the app preview only; it does not inject an overlay into Minecraft.");
        String[] styles = {"Classic +", "Dot", "Small cross", "Circle"};
        RadioGroup group = new RadioGroup(this);
        for (String style : styles) {
            RadioButton b = new RadioButton(this);
            b.setText(style);
            b.setTextColor(Color.WHITE);
            group.addView(b);
        }
        group.check(group.getChildAt(0).getId());
        content.addView(group);
        content.addView(text("Preview:  +", 34, cyan, true));
    }

    private void showZoom() {
        heading("ZOOM SETTINGS", "This stores a preferred zoom value for your own reference. It cannot change Minecraft's camera from a separate app.");
        SeekBar seek = new SeekBar(this);
        seek.setMax(10);
        seek.setProgress(3);
        content.addView(seek);
        TextView value = text("Zoom preference: 1.3×", 18, cyan, true);
        content.addView(value);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean u) { value.setText("Zoom preference: " + (1.0 + p * 0.1) + "×"); }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
    }

    private void showPacks() {
        heading("PACK MANAGER", "To manage packs, open Minecraft and go to Settings → Global Resources, or activate packs in a world's settings.");
        Button open = new Button(this);
        open.setText("OPEN MINECRAFT");
        open.setTextColor(Color.WHITE);
        open.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(20, 95, 145)));
        open.setOnClickListener(v -> {
            try {
                startActivity(getPackageManager().getLaunchIntentForPackage("com.mojang.minecraftpe"));
            } catch (Exception e) {
                status.setText("Minecraft could not be opened. Make sure it is installed.");
            }
        });
        content.addView(open);
    }

    private void showAbout() {
        heading("ABOUT JBBT", "JBBT CLIENT is an independent Android companion app concept with a neon-blue dashboard. It is not affiliated with Mojang or Flarial. It does not modify Minecraft, inject code, read live game data, or provide unfair gameplay automation.");
    }
}
