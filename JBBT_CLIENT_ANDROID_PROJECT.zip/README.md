# JBBT CLIENT — Android project

This is an Android Studio source project for a simple JBBT CLIENT companion app.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Let Gradle sync and install the Android SDK platform 35 if prompted.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio creates the APK under `app/build/outputs/apk/debug/`.

## What the app does
- Neon-blue JBBT dashboard
- HUD preference toggles (preview/preferences only)
- Crosshair style selector (preview only)
- Zoom preference slider (does not alter Minecraft camera)
- Button to launch Minecraft
- Pack-management guidance

## Important limitations
This is a companion app, not a modified Minecraft client. A normal Android app cannot read Minecraft's live FPS/CPS/ping/armor/keystrokes or draw an in-game overlay over Minecraft without supported integration and permissions. This project does not inject into or modify Minecraft.

Package: `com.jbbt.client`
Minimum Android: 6.0 (API 23)
Target SDK: 35
